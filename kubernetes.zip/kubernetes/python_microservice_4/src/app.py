# app.py

from flask import Flask, jsonify
import os

app = Flask(__name__)

# Get configuration from environment variables
my_key = os.environ.get("MY_KEY", "default_value_from_code")
database_url = os.environ.get("DATABASE_URL", "default_database_url")

# Read secrets from the mounted files
secret_file_path = "/etc/my-secrets/secret_key"
if os.path.exists(secret_file_path):
    with open(secret_file_path, 'r') as file:
        secret_key = file.read()
else:
    secret_key = "default_secret_key"

# Read the second secret from the mounted file
second_secret_file_path = "/etc/my-secrets/another_secret_key"
if os.path.exists(second_secret_file_path):
    with open(second_secret_file_path, 'r') as file:
        another_secret_key = file.read()
else:
    another_secret_key = "default_another_secret_key"

@app.route('/')
def hello_world():
    return jsonify({
        'my_key': my_key,
        'database_url': database_url,
        'secret_key': secret_key,
        'another_secret_key': another_secret_key
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
